package es.uji.TooPots.model;

public class Level {
	public static final String EXPERT = "Expert";
	public static final String BEGGINER = "Begginer";
	public static final String INTERMEDIATE = "Intermediate";
}

package es.uji.TooPots.model;

public enum TypeActivityName {

}

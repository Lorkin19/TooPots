package es.uji.TooPots.model;

public interface User {
	public String getMail();
	public String getPwd();
	public String getUsername();
	public void setMail(String mail);
	public void setPwd(String pwd);
	public void setUsername(String username);
	
}

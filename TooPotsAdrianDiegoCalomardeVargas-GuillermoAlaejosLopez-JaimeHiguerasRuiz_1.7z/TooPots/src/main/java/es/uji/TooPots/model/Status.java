package es.uji.TooPots.model;

public class Status {
	public static final String PENDING = "Pending";
	public static final String APPROVED = "Approved";
	public static final String REJECTED = "Rejected";
}
